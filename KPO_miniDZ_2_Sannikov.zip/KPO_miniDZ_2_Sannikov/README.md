# Система управления зоопарком

Проект реализует REST API для управления животными, вольерами и расписанием кормлений 
с применением принципов **Domain-Driven Design (DDD)** и **Clean Architecture**.

---

## Реализованный функционал

### Управление животными
- **Добавление/получение/удаление** животных
- **Доменные сущности**: 
  - `Animal` (атрибуты: `Name`, `Breed`, `BirthDate`, `Gender`, `FavoriteFood`, `HealthStatus`, `EnclosureId`, `Hunger`)
  - Методы: `Feed()`, `Treat()`, `SetEnclosureId()`, `ClearDomainEvents()`
- **Репозиторий**: `InMemoryAnimalRepository` (реализует `IAnimalRepository`)
- **Контроллер**: `AnimalController`

### Управление вольерами
- **Операции**: создание, обновление, удаление, получение информации
- **Доменные сущности**: 
  - `Enclosure` (атрибуты: `Type`, `Length`, `Width`, `Height`, `MaxCapacity`)
  - Методы: `AddAnimal()`, `RemoveAnimal()`, `Clean()`
- **Репозиторий**: `InMemoryEnclosureRepository` (реализует `IEnclosureRepository`)
- **Контроллер**: `EnclosuresController`

### Управление расписанием кормлений
- **Создание/обновление/получение/удаление** расписаний
- **Доменные сущности**: 
  - `FeedingSchedule` (атрибуты: `Id`, `Animal`, `FeedingTime`, `Food`, `Done`)
  - Методы: `ChangeFeedingTime()`, `MarkDone()`
- **Репозиторий**: `InMemoryFeedingScheduleRepository` (реализует `IFeedingScheduleRepository`)
- **Контроллер**: `FeedingSchedulesController`
- **Сервис**: `FeedingOrganizationService`

### Сервисы
- **Перемещение животных**:
  - Генерация доменного события `AnimalMovedEvent` при смене вольера
  - Сервис: `AnimalTransferService`
- **Статистика зоопарка**:
  - Общее количество животных (`GetAnimalAmount()`)
  - Количество вольеров со свободным местом (`GetAmountOfEnclosuresWithFreeSpace()`)
  - Сервис: `ZooStatisticsService`

---

## Применённые архитектурные подходы

### Domain-Driven Design (DDD)
| Концепция             | Реализация                                                                 |
|-----------------------|----------------------------------------------------------------------------|
| **Bounded Context**   | Контексты: животные, вольеры, расписания кормлений                        |
| **Агрегаты**          | `Animal`, `Enclosure`, `FeedingSchedule` (контроль бизнес-правил)         |
| **Value Objects**     | `EnclosureType`, `AnimalGender`, `AnimalHealthStatus`                     |
| **Доменные события**  | `AnimalMovedEvent`, `FeedingTimeEvent` (отслеживание изменений состояния) |

### Clean Architecture
| Слой             | Описание                                                                 |
|------------------|--------------------------------------------------------------------------|
| **Domain**       | Сущности, value objects, события, интерфейсы репозиториев               |
| **Application**  | Сервисы (`AnimalTransferService`, `FeedingOrganizationService`)         |
| **Infrastructure**| In-memory репозитории, `DomainEventDispatcher`                          |
| **Presentation** | REST API контроллеры (`AnimalController`, `EnclosureController`)      |

