using Application.Services;
using Domain.RepositoryInterfaces;
using Moq;
using Xunit;

namespace ZooTests.Application.Services
{
    public class ZooStatisticsServiceTests
    {
        private readonly Mock<IAnimalRepository> _animalRepoMock = new();
        private readonly Mock<IEnclosureRepository> _enclosureRepoMock = new();
        private readonly ZooStatisticsService _service;

        public ZooStatisticsServiceTests()
        {
            _service = new ZooStatisticsService(
                _animalRepoMock.Object,
                _enclosureRepoMock.Object
            );
        }

        [Fact]
        public void GetAnimalAmount_ShouldReturnCorrectCount()
        {
            // Arrange
            _animalRepoMock.Setup(x => x.GetAnimalsCount()).Returns(42);

            // Act
            var result = _service.GetAnimalAmount();

            // Assert
            Assert.Equal(42, result);
        }

        [Fact]
        public void GetAmountOfEnclosuresWithFreeSpace_ShouldCalculateCorrectly()
        {
            // Arrange
            _enclosureRepoMock.Setup(x => x.GetFreeEnclosureCount()).Returns(3);

            // Act
            var result = _service.GetAmountOfEnclosuresWithFreeSpace();

            // Assert
            Assert.Equal(3, result);
        }

        [Fact]
        public void GetAnimalAmount_ShouldReturnZeroForEmptyRepository()
        {
            // Arrange
            _animalRepoMock.Setup(x => x.GetAnimalsCount()).Returns(0);

            // Act
            var result = _service.GetAnimalAmount();

            // Assert
            Assert.Equal(0, result);
        }
    }
}