using Application.EventHandlers;
using Application.Services;
using Domain.Enities;
using Domain.Events;
using Domain.RepositoryInterfaces;
using Domain.ValueObjects;
using Moq;
using Xunit;

namespace ZooTests.Application.Services
{
    public class FeedingOrganizationServiceTests
    {
        private readonly Mock<IFeedingScheduleRepository> _scheduleRepoMock = new();
        private readonly Mock<IDomainEventDispatcher> _eventDispatcherMock = new();
        private readonly FeedingOrganizationService _service;

        public FeedingOrganizationServiceTests()
        {
            _service = new FeedingOrganizationService(
                _scheduleRepoMock.Object,
                _eventDispatcherMock.Object
            );
        }

        [Fact]
        public void AddScheduleFeeding_ShouldAddToRepositoryAndDispatchEvent()
        {
            // Arrange
            var animal = CreateTestAnimal();
            var time = DateTime.Now.AddHours(2);
    
            // Act
            _service.AddScheduleFeeding(animal, time, "Meat");

            // Assert
            _scheduleRepoMock.Verify(x => 
                x.Add(It.Is<FeedingSchedule>(s => 
                    s.Animal == animal &&
                    s.Food == "Meat"
                )), Times.Once);
    
            _eventDispatcherMock.Verify(x => 
                x.Dispatch(It.IsAny<FeedingTimeEvent>()), Times.Once);
        }

        [Fact]
        public void GetFeedingSchedules_ShouldReturnAllFromRepository()
        {
            // Arrange
            var expected = new List<FeedingSchedule> { CreateTestSchedule() };
            _scheduleRepoMock.Setup(x => x.GetAllFeedingSchedules()).Returns(expected);

            // Act
            var result = _service.GetFeedingSchedules();

            // Assert
            Assert.Equal(expected, result);
        }
        
        private Animal CreateTestAnimal()
        {
            return new Animal(
                Guid.NewGuid(), "Tiger", "Tony",
                DateTime.Now, AnimalGender.Female,
                "Fish", AnimalHealthStatus.Healthy, 3);
        }

        private FeedingSchedule CreateTestSchedule()
        {
            return new FeedingSchedule(
                Guid.NewGuid(),
                CreateTestAnimal(),
                DateTime.Now.AddHours(1),
                "Meat"
            );
        }
    }
}