using System.ComponentModel.DataAnnotations;
using Application.Dtos;
using Domain.ValueObjects;
using Xunit;

namespace ZooTests.Application.Dtos
{
    public class EnclosureCreateDtoTests
    {
        [Theory]
        [InlineData(0, false)]
        [InlineData(1, true)]
        [InlineData(uint.MaxValue, true)]
        public void MaxNumberOfAnimal_ValidationTests(uint value, bool isValid)
        {
            // Arrange
            var dto = new EnclosureCreateDto 
            {
                Type = EnclosureType.ForPredators,
                Length = 10,
                Width = 10,
                Height = 5,
                MaxNumberOfAnimal = value
            };

            // Act
            var results = ValidateModel(dto);

            // Assert
            Assert.Equal(isValid, results.Count == 0);
        }

        private static List<ValidationResult> ValidateModel(object model)
        {
            var results = new List<ValidationResult>();
            var context = new ValidationContext(model);
            Validator.TryValidateObject(model, context, results, true);
            return results;
        }
    }
}