using System.ComponentModel.DataAnnotations;
using Application.Dtos;
using Xunit;

namespace ZooTests.Application.Dtos
{
    public class FeedingScheduleCreateDtoTests
    {
        [Fact]
        public void ValidDto_ShouldPassValidation()
        {
            // Arrange
            var dto = new FeedingScheduleCreateDto 
            {
                AnimalId = Guid.NewGuid(),
                Food = "Meat",
                FeedingTime = DateTime.Now,
                Done = false
            };

            // Act
            var results = ValidateModel(dto);

            // Assert
            Assert.Empty(results);
        }

        private static List<ValidationResult> ValidateModel(object model)
        {
            var results = new List<ValidationResult>();
            var context = new ValidationContext(model);
            Validator.TryValidateObject(model, context, results, true);
            return results;
        }
    }
}