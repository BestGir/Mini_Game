using System.ComponentModel.DataAnnotations;
using Application.Dtos;
using Domain.ValueObjects;
using Xunit;

namespace ZooTests.Application.Dtos
{
    public class AnimalCreateDtoTests
    {
        [Theory]
        [InlineData(null, false, "Breed")]
        [InlineData("", false, "Breed")]
        [InlineData("Lion", true, null)]
        public void Breed_ValidationTests(string breed, bool isValid, string errorField)
        {
            // Arrange
            var dto = new AnimalCreateDto 
            {
                Breed = breed,
                Name = "Simba",
                BirthDate = DateTime.Now,
                Gender = AnimalGender.Male,
                FavoriteFood = "Meat",
                HealthStatus = AnimalHealthStatus.Healthy,
                Hunger = 5,
                Happiness = 5,
                EnclosureId = Guid.NewGuid()
            };

            // Act
            var results = ValidateModel(dto);

            // Assert
            Assert.Equal(isValid, results.Count == 0);
            if (!isValid) Assert.Contains(errorField, results[0].MemberNames);
        }

        [Theory]
        [InlineData(-1, false)]
        [InlineData(0, true)]
        [InlineData(10, true)]
        [InlineData(11, false)]
        public void Hunger_RangeValidationTests(int value, bool isValid)
        {
            // Arrange
            var dto = new AnimalCreateDto 
            {
                Breed = "Lion",
                Name = "Simba",
                BirthDate = DateTime.Now,
                Gender = AnimalGender.Male,
                FavoriteFood = "Meat",
                HealthStatus = AnimalHealthStatus.Healthy,
                Hunger = value,
                Happiness = 5,
                EnclosureId = Guid.NewGuid()
            };

            // Act
            var results = ValidateModel(dto);

            // Assert
            Assert.Equal(isValid, results.Count == 0);
        }

        private static List<ValidationResult> ValidateModel(object model)
        {
            var results = new List<ValidationResult>();
            var context = new ValidationContext(model);
            Validator.TryValidateObject(model, context, results, true);
            return results;
        }
    }
}