using System.ComponentModel.DataAnnotations;
using Application.Dtos;
using Xunit;

namespace ZooTests.Application.Dtos
{
    public class AnimalTransferDtoTests
    {
        [Fact]
        public void ValidDto_ShouldPassValidation()
        {
            // Arrange
            var dto = new AnimalTransferDto 
            {
                AnimalId = Guid.NewGuid(),
                NewEnclosureId = Guid.NewGuid()
            };

            // Act
            var results = ValidateModel(dto);

            // Assert
            Assert.Empty(results);
        }

        private static List<ValidationResult> ValidateModel(object model)
        {
            var results = new List<ValidationResult>();
            var context = new ValidationContext(model);
            Validator.TryValidateObject(model, context, results, true);
            return results;
        }
    }
}