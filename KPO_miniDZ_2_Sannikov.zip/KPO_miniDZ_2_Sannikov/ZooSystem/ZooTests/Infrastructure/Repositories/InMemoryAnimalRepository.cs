using Domain.Enities;
using Domain.ValueObjects;
using Infrastructure.Repositories;
using Xunit;

namespace ZooTests.Infrastructure.Repositories
{
    public class InMemoryAnimalRepositoryTests
    {
        private readonly InMemoryAnimalRepository _repository = new();

        [Fact]
        public void Add_ShouldAddAnimalToRepository()
        {
            // Arrange
            var animal = new Animal(
                Guid.NewGuid(), "Lion", "Simba",
                DateTime.Now, AnimalGender.Male,
                "Meat", AnimalHealthStatus.Healthy, 5);

            // Act
            _repository.Add(animal);
            
            // Assert
            Assert.Single(_repository.GetAll());
        }

        [Fact]
        public void GetById_ShouldReturnCorrectAnimal()
        {
            // Arrange
            var id = Guid.NewGuid();
            var animal = new Animal(id, "Tiger", "Tony",
                DateTime.Now, AnimalGender.Female,
                "Fish", AnimalHealthStatus.Healthy, 3);
            
            _repository.Add(animal);

            // Act
            var result = _repository.GetAnimalById(id);

            // Assert
            Assert.Equal(id, result.AnimalId);
        }

        [Fact]
        public void Remove_ShouldDeleteAnimalFromRepository()
        {
            // Arrange
            var animal = new Animal(
                Guid.NewGuid(), "Bear", "Baloo",
                DateTime.Now, AnimalGender.Male,
                "Honey", AnimalHealthStatus.Healthy, 4);
            
            _repository.Add(animal);

            // Act
            _repository.Remove(animal.AnimalId);

            // Assert
            Assert.Empty(_repository.GetAll());
        }

        [Fact]
        public void Update_ShouldModifyExistingAnimal()
        {
            // Arrange
            var originalAnimal = new Animal(
                Guid.NewGuid(), "Wolf", "Ghost",
                DateTime.Now, AnimalGender.Male,
                "Meat", AnimalHealthStatus.Healthy, 5);
            
            _repository.Add(originalAnimal);
            
            var updatedAnimal = new Animal(
                originalAnimal.AnimalId, "Wolf", "White Fang",
                originalAnimal.BirthDate, originalAnimal.Gender,
                originalAnimal.FavoriteFood, AnimalHealthStatus.Sick, 8);

            // Act
            _repository.Update(updatedAnimal);
            var result = _repository.GetAnimalById(originalAnimal.AnimalId);

            // Assert
            Assert.Equal("White Fang", result.Name);
            Assert.Equal(AnimalHealthStatus.Sick, result.HealthStatus);
        }

        [Fact]
        public void GetAnimalsCount_ShouldReturnCorrectNumber()
        {
            // Arrange
            _repository.Add(new Animal(Guid.NewGuid(), "A", "A", 
                DateTime.Now, AnimalGender.Male, "Food", AnimalHealthStatus.Healthy, 1));
            
            _repository.Add(new Animal(Guid.NewGuid(), "B", "B", 
                DateTime.Now, AnimalGender.Female, "Food", AnimalHealthStatus.Healthy, 1));

            // Act
            var count = _repository.GetAnimalsCount();

            // Assert
            Assert.Equal(2, count);
        }

        [Fact]
        public void GetAnimalById_ShouldThrowForNonexistentId()
        {
            // Arrange
            var invalidId = Guid.NewGuid();

            // Assert
            Assert.Throws<KeyNotFoundException>(() => 
                _repository.GetAnimalById(invalidId));
        }
    }
}