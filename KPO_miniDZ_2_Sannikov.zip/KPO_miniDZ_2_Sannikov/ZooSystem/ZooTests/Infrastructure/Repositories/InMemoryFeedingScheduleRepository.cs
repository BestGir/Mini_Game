using Domain.Enities;
using Domain.ValueObjects;
using Infrastructure.Repositories;
using Xunit;

namespace ZooTests.Infrastructure.Repositories
{
    public class InMemoryFeedingScheduleRepositoryTests
    {
        private readonly InMemoryFeedingScheduleRepository _repository = new();

        [Fact]
        public void AddSchedule_ShouldStoreInRepository()
        {
            // Arrange
            var schedule = CreateTestSchedule();

            // Act
            _repository.Add(schedule);

            // Assert
            Assert.Single(_repository.GetAllFeedingSchedules());
        }

        [Fact]
        public void RemoveSchedule_ShouldDeleteFromRepository()
        {
            // Arrange
            var schedule = CreateTestSchedule();
            _repository.Add(schedule);

            // Act
            _repository.Remove(schedule.FeedingScheduleId);

            // Assert
            Assert.Empty(_repository.GetAllFeedingSchedules());
        }

        private FeedingSchedule CreateTestSchedule()
        {
            return new FeedingSchedule(
                Guid.NewGuid(),
                new Animal(
                    Guid.NewGuid(), "Test", "Test",
                    DateTime.Now, AnimalGender.Male,
                    "Food", AnimalHealthStatus.Healthy, 5),
                DateTime.Now.AddHours(1),
                "Food"
            );
        }
    }
}