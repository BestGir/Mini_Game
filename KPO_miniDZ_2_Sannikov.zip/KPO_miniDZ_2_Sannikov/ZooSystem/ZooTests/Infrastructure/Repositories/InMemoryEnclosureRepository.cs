using Domain.Enities;
using Domain.ValueObjects;
using Infrastructure.Repositories;
using Xunit;

namespace ZooTests.Infrastructure.Repositories
{
    public class InMemoryEnclosureRepositoryTests
    {
        private readonly InMemoryEnclosureRepository _repository = new();

        [Fact]
        public void GetEnclosureById_ShouldReturnCorrectEnclosure()
        {
            // Arrange
            var id = Guid.NewGuid();
            var enclosure = CreateTestEnclosure(id);
            _repository.Add(enclosure);

            // Act
            var result = _repository.GetEnclosureById(id);

            // Assert
            Assert.Equal(id, result.EnclosureId);
        }

        private Enclosure CreateTestEnclosure(
            Guid? id = null, 
            uint maxAnimals = 5)
        {
            return new Enclosure(
                id ?? Guid.NewGuid(),
                EnclosureType.ForPredators,
                10, 10, 5,
                0,
                maxAnimals,
                new List<Animal>(),
                100
            );
        }
    }
}
