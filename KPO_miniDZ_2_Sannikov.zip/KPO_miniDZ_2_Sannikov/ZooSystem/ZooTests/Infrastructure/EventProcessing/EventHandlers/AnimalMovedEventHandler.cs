using Domain.Enities;
using Domain.Events;
using Domain.RepositoryInterfaces;
using Domain.ValueObjects;
using Infrastructure.EventProcessing.EventHandlers;
using Moq;
using Xunit;

namespace ZooTests.Infrastructure.EventProcessing.EventHandlers
{
    public class AnimalMovedEventHandlerTests
    {
        private readonly Mock<IAnimalRepository> _animalRepoMock = new();
        private readonly Mock<IEnclosureRepository> _enclosureRepoMock = new();
        private readonly AnimalMovedEventHandler _handler;

        public AnimalMovedEventHandlerTests()
        {
            _handler = new AnimalMovedEventHandler(
                _animalRepoMock.Object,
                _enclosureRepoMock.Object
            );
        }

        [Fact]
        public void Handle_ShouldTransferAnimalBetweenEnclosures()
        {
            // Arrange
            var animal = new Animal(
                Guid.NewGuid(), "Wolf", "Ghost",
                DateTime.Now, AnimalGender.Male,
                "Meat", AnimalHealthStatus.Healthy, 5);
            
            var prevEnclosure = new Enclosure(
                Guid.NewGuid(), EnclosureType.ForPredators,
                15, 10, 5, 1, 5, new List<Animal>{animal}, 100);
            
            var newEnclosure = new Enclosure(
                Guid.NewGuid(), EnclosureType.ForPredators,
                20, 15, 6, 0, 5, new List<Animal>(), 100);

            var @event = new AnimalMovedEvent(
                animal.AnimalId, 
                prevEnclosure.EnclosureId, 
                newEnclosure.EnclosureId
            );

            _animalRepoMock.Setup(x => x.GetAnimalById(@event.AnimalId)).Returns(animal);
            _enclosureRepoMock.SetupSequence(x => x.GetEnclosureById(It.IsAny<Guid>()))
                .Returns(prevEnclosure)
                .Returns(newEnclosure);

            // Act
            _handler.Handle(@event);

            // Assert
            Assert.Empty(prevEnclosure.GetAnimals());
            Assert.Contains(animal, newEnclosure.GetAnimals());
        }

    }
}