using Application.EventHandlers;
using Application.Services;
using Domain.Enities;
using Domain.Events;
using Domain.RepositoryInterfaces;
using Domain.ValueObjects;
using Infrastructure.EventProcessing.EventHandlers;
using Moq;
using Xunit;

namespace ZooTests.Infrastructure.EventProcessing.EventHandlers
{
    public class FeedingTimeEventHandlerTests
    {
        [Fact]
        public void Handle_ShouldMarkScheduleAsDone()
        {
            // Arrange
            var mockScheduleRepo = new Mock<IFeedingScheduleRepository>();
            var mockEventDispatcher = new Mock<IDomainEventDispatcher>();
            
            var feedingService = new FeedingOrganizationService(
                mockScheduleRepo.Object,
                mockEventDispatcher.Object
            );
            
            var schedule = new FeedingSchedule(
                Guid.NewGuid(),
                new Animal(
                    Guid.NewGuid(), "Bear", "Baloo",
                    DateTime.Now, AnimalGender.Male,
                    "Honey", AnimalHealthStatus.Healthy, 4),
                DateTime.Now.AddHours(1),
                "Honey"
            );
            
            var @event = new FeedingTimeEvent(schedule);
            var handler = new FeedingTimeEventHandler(feedingService);

            // Act
            handler.Handle(@event);

            // Assert
            Assert.True(schedule.Done);
        }
    }
}