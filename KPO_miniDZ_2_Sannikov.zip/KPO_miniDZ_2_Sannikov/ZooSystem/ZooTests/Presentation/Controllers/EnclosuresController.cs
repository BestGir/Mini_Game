using Application.Dtos;
using Domain.Enities;
using Domain.RepositoryInterfaces;
using Domain.ValueObjects;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Presentation.Controllers;
using Xunit;

namespace ZooTests.Presentation.Controllers
{
    public class EnclosuresControllerTests
    {
        private readonly Mock<IEnclosureRepository> _enclosureRepoMock = new Mock<IEnclosureRepository>();
        private readonly EnclosureController _controller;

        public EnclosuresControllerTests()
        {
            _controller = new EnclosureController(_enclosureRepoMock.Object);
        }

        [Fact]
        public void AddEnclosure_ValidRequest_ReturnsCreatedResult()
        {
            // Arrange
            var dto = new EnclosureCreateDto
            {
                Type = EnclosureType.ForPredators,
                Length = 10,
                Width = 5,
                Height = 3,
                MaxNumberOfAnimal = 5
            };

            // Act
            var result = _controller.AddEnclosure(dto);

            // Assert
            Assert.IsType<CreatedAtActionResult>(result);
            _enclosureRepoMock.Verify(r => r.Add(It.Is<Enclosure>(e => e.Type == dto.Type)), Times.Once);
        }

        [Fact]
        public void DeleteEnclosure_NonExistingId_ReturnsNotFound()
        {
            // Arrange
            var enclosureId = Guid.NewGuid();
            _enclosureRepoMock.Setup(r => r.GetEnclosureById(enclosureId)).Throws<KeyNotFoundException>();

            // Act
            var result = _controller.DeleteEnclosure(enclosureId);

            // Assert
            Assert.IsType<NotFoundObjectResult>(result);
        }
    }
}