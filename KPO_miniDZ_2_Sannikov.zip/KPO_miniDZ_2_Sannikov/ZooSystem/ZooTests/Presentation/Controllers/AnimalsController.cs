using Application.Dtos;
using Application.EventHandlers;
using Application.Services;
using Domain.Enities;
using Domain.RepositoryInterfaces;
using Domain.ValueObjects;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Presentation.Controllers;
using Xunit;

namespace ZooTests.Presentation.Controllers
{
    public class AnimalsControllerTests
    {
        private readonly Mock<IAnimalRepository> _animalRepoMock = new();
        private readonly Mock<IEnclosureRepository> _enclosureRepoMock = new();
        private readonly Mock<IDomainEventDispatcher> _eventDispatcherMock = new();
        private readonly AnimalController _controller;
        private readonly AnimalTransferService _transferService;

        public AnimalsControllerTests()
        {
            _transferService = new AnimalTransferService(
                _animalRepoMock.Object,
                _enclosureRepoMock.Object,
                _eventDispatcherMock.Object
            );

            _controller = new AnimalController(
                _animalRepoMock.Object,
                _enclosureRepoMock.Object,
                _transferService
            );
        }

        [Fact]
        public void AddAnimal_ValidRequest_ReturnsCreatedResult()
        {
            // Arrange
            var dto = new AnimalCreateDto
            {
                Breed = "Tiger",
                Name = "Tigra",
                EnclosureId = Guid.NewGuid(),
                BirthDate = DateTime.Now,
                Gender = AnimalGender.Male,
                FavoriteFood = "Meat",
                HealthStatus = AnimalHealthStatus.Healthy,
                Hunger = 5,
                Happiness = 5
            };

            var enclosure = new Enclosure(
                dto.EnclosureId, 
                EnclosureType.ForPredators, 
                10, 5, 3, 
                0, 5, 
                new List<Animal>(), 
                100
            );

            _enclosureRepoMock.Setup(r => r.GetEnclosureById(dto.EnclosureId)).Returns(enclosure);

            // Act
            var result = _controller.AddAnimal(dto);

            // Assert
            Assert.IsType<CreatedAtActionResult>(result);
            _animalRepoMock.Verify(r => r.Add(It.IsAny<Animal>()), Times.Once);
        }

        [Fact]
        public void DeleteAnimal_ExistingId_ReturnsNoContent()
        {
            // Arrange
            var animalId = Guid.NewGuid();
            _animalRepoMock.Setup(r => r.GetAnimalById(animalId))
                .Returns(new Animal(
                    Guid.NewGuid(), "Tiger", "Tigra", 
                    DateTime.Now, AnimalGender.Male, "Meat", 
                    AnimalHealthStatus.Healthy, 5
                ));

            // Act
            var result = _controller.DeleteAnimal(animalId);

            // Assert
            Assert.IsType<NoContentResult>(result);
            _animalRepoMock.Verify(r => r.Remove(animalId), Times.Once);
        }
    }
}