using Application.Dtos;
using Application.EventHandlers;
using Application.Services;
using Domain.Enities;
using Domain.RepositoryInterfaces;
using Domain.ValueObjects;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Presentation.Controllers;
using Xunit;

namespace ZooTests.Presentation.Controllers
{
    public class FeedingSchedulesControllerTests
    {
        private readonly Mock<IFeedingScheduleRepository> _feedingRepoMock = new();
        private readonly Mock<IDomainEventDispatcher> _eventDispatcherMock = new();
        private readonly Mock<IAnimalRepository> _animalRepoMock = new();
        private readonly FeedingScheduleController _controller;

        public FeedingSchedulesControllerTests()
        {
            var feedingService = new FeedingOrganizationService(
                _feedingRepoMock.Object,
                _eventDispatcherMock.Object
            );

            _controller = new FeedingScheduleController(
                feedingService,
                _animalRepoMock.Object,
                _feedingRepoMock.Object
            );
        }

        [Fact]
        public void AddFeedingSchedule_ValidRequest_ReturnsCreatedResult()
        {
            // Arrange
            var dto = new FeedingScheduleCreateDto
            {
                AnimalId = Guid.NewGuid(),
                FeedingTime = DateTime.Now.AddHours(2),
                Food = "Meat"
            };
            _animalRepoMock.Setup(r => r.GetAnimalById(dto.AnimalId))
                .Returns(new Animal(
                    Guid.NewGuid(), "Lion", "Simba", DateTime.Now, 
                    AnimalGender.Male, "Meat", AnimalHealthStatus.Healthy, 5
                ));

            // Act
            var result = _controller.AddFeedingSchedule(dto);

            // Assert
            Assert.IsType<CreatedAtActionResult>(result);
            _feedingRepoMock.Verify(r => r.Add(It.IsAny<FeedingSchedule>()), Times.Once);
        }

        [Fact]
        public void MarkFeedingAsDone_ValidId_ReturnsOk()
        {
            // Arrange
            var scheduleId = Guid.NewGuid();
            var schedule = new FeedingSchedule(scheduleId, new Animal(
                id: Guid.NewGuid(),
                breed: "Lion",
                name: "Simba",
                birthDate: DateTime.Now.AddYears(-1),
                gender: AnimalGender.Male,
                favoriteFood: "Meat",
                healthStatus: AnimalHealthStatus.Healthy,
                hunger: 5
            ), DateTime.Now, "Food");
            _feedingRepoMock.Setup(r => r.GetFeedingScheduleById(scheduleId)).Returns(schedule);

            // Act
            var result = _controller.MarkFeedingAsDone(scheduleId);

            // Assert
            Assert.IsType<OkResult>(result);
            _feedingRepoMock.Verify(r => r.Update(schedule), Times.Once);
        }
    }
}