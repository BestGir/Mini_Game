using Domain.Enities;
using Domain.ValueObjects;
using FluentAssertions;
using Xunit;

namespace ZooTests.Domain.Enities;

public class FeedingScheduleTests
{
    [Fact]
    public void Constructor_WithValidParameters_InitializesAllProperties()
    {
        // Arrange
        var feedingScheduleId = Guid.NewGuid();
        var animal = new Animal(
            id: Guid.NewGuid(),
            breed: "Лев",
            name: "Симба",
            birthDate: DateTime.Now,
            gender: AnimalGender.Male,
            favoriteFood: "Мясо",
            healthStatus: AnimalHealthStatus.Healthy,
            hunger: 5,
            happiness: 5
        );
        var feedingTime = DateTime.UtcNow.AddHours(2);
        var food = "Мясо";

        // Act
        var feedingSchedule = new FeedingSchedule(
            feedingScheduleId,
            animal,
            feedingTime,
            food
        );

        // Assert
        feedingSchedule.FeedingScheduleId.Should().Be(feedingScheduleId);
        feedingSchedule.Animal.Should().Be(animal);
        feedingSchedule.FeedingTime.Should().Be(feedingTime);
        feedingSchedule.Food.Should().Be(food);
        feedingSchedule.Done.Should().BeFalse();
    }
    [Fact]
    public void ChangeFeedingTime_WithNewDateTime_UpdatesProperty()
    {
        // Arrange
        var initialFeedingTime = DateTime.UtcNow;
        var feedingSchedule = new FeedingSchedule(
            Guid.NewGuid(),
            new Animal(
                id: Guid.NewGuid(),
                breed: "Лев",
                name: "Симба",
                birthDate: DateTime.Now,
                gender: AnimalGender.Male,
                favoriteFood: "Мясо",
                healthStatus: AnimalHealthStatus.Healthy,
                hunger: 5,
                happiness: 5
            ),
            initialFeedingTime,
            "Мясо"
        );
        var newFeedingTime = DateTime.UtcNow.AddHours(3);

        // Act
        feedingSchedule.ChangeFeedingTime(newFeedingTime);

        // Assert
        feedingSchedule.FeedingTime.Should().Be(newFeedingTime);
        feedingSchedule.FeedingTime.Should().NotBe(initialFeedingTime);
    }
    [Fact]
    public void MarkDone_WhenCalled_SetsDoneToTrue()
    {
        // Arrange
        var feedingSchedule = new FeedingSchedule(
                Guid.NewGuid(),
                new Animal(
                    id: Guid.NewGuid(),
                    breed: "Лев",
                    name: "Симба",
                    birthDate: DateTime.Now,
                    gender: AnimalGender.Male,
                    favoriteFood: "Мясо",
                    healthStatus: AnimalHealthStatus.Healthy,
                    hunger: 5,
                    happiness: 5
                ),
            DateTime.UtcNow,
        "Мясо",
        done: false
            );

        // Act
        feedingSchedule.MarkDone();

        // Assert
        feedingSchedule.Done.Should().BeTrue();
    }
    [Fact]
    public void UnMarkDone_WhenCalled_SetsDoneToFalse()
    {
        // Arrange
        var feedingSchedule = new FeedingSchedule(
                Guid.NewGuid(),
                new Animal(
                    id: Guid.NewGuid(),
                    breed: "Лев",
                    name: "Симба",
                    birthDate: DateTime.Now,
                    gender: AnimalGender.Male,
                    favoriteFood: "Мясо",
                    healthStatus: AnimalHealthStatus.Healthy,
                    hunger: 5,
                    happiness: 5
                ),
            DateTime.UtcNow,
        "Мясо",
        done: true
            );

        // Act
        feedingSchedule.UnMarkDone();

        // Assert
        feedingSchedule.Done.Should().BeFalse();
    }
}