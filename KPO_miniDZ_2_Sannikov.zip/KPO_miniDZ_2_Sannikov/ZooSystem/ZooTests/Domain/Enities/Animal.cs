using Domain.Enities;
using Domain.ValueObjects;
using FluentAssertions;
using Xunit;

namespace ZooTests.Domain.Enities;

public partial class AnimalTests
{
    [Fact]
    public void Feed_WithFavoriteFood_DecreasesHungerAndIncreasesHappiness()
    {
        // Arrange
        var animal = new Animal(
            id: Guid.NewGuid(),
            breed: "Лев",
            name: "Симба",
            birthDate: DateTime.Now,
            gender: AnimalGender.Male,
            favoriteFood: "мясо", 
            healthStatus: AnimalHealthStatus.Healthy,
            hunger: 5,
            happiness: 5
        );

        // Act
        animal.Feed("Мясо"); 

        // Assert
        animal.Hunger.Should().Be(4);
        animal.Happiness.Should().Be(6); 
    }

    [Fact]
    public void Feed_WithNonFavoriteFood_DecreasesHungerAndDecreasesHappiness()
    {
        // Arrange
        var animal = new Animal(
            id: Guid.NewGuid(),
            breed: "Лев",
            name: "Симба",
            birthDate: DateTime.Now,
            gender: AnimalGender.Male,
            favoriteFood: "мясо",
            healthStatus: AnimalHealthStatus.Healthy,
            hunger: 5,
            happiness: 5
        );

        // Act
        animal.Feed("Трава");

        // Assert
        animal.Hunger.Should().Be(4);
        animal.Happiness.Should().Be(4);
    }
    [Fact]
    public void Treat_WhenHappinessIsHigh_SetsHealthStatusToHealthy()
    {
        // Arrange
        var animal = new Animal(
            id: Guid.NewGuid(),
            breed: "Лев",
            name: "Симба",
            birthDate: DateTime.Now,
            gender: AnimalGender.Male,
            favoriteFood: "мясо",
            healthStatus: AnimalHealthStatus.Sick,
            hunger: 5,
            happiness: 10
        );

        // Act
        animal.Treat();

        // Assert
        animal.HealthStatus.Should().Be(AnimalHealthStatus.Healthy);
    }

    [Fact]
    public void Treat_WhenHappinessIsLow_SetsHealthStatusToSick()
    {
        // Arrange
        var animal = new Animal(
            id: Guid.NewGuid(),
            breed: "Лев",
            name: "Симба",
            birthDate: DateTime.Now,
            gender: AnimalGender.Male,
            favoriteFood: "мясо",
            healthStatus: AnimalHealthStatus.Healthy,
            hunger: 5,
            happiness: 3
        );

        // Act
        animal.Treat();

        // Assert
        animal.HealthStatus.Should().Be(AnimalHealthStatus.Sick);
    }
    [Fact]
    public void ClearDomainEvents_RemovesAllEvents()
    {
        // Arrange
        var animal = new Animal(
            id: Guid.NewGuid(),
            breed: "Лев",
            name: "Симба",
            birthDate: DateTime.Now,
            gender: AnimalGender.Male,
            favoriteFood: "мясо",
            healthStatus: AnimalHealthStatus.Healthy,
            hunger: 5,
            happiness: 5
        );

        animal.SetNewEnclosureId(Guid.NewGuid());

        // Act
        animal.ClearDomainEvents();

        // Assert
        animal.DomainEvents.Should().BeEmpty();
    }
}