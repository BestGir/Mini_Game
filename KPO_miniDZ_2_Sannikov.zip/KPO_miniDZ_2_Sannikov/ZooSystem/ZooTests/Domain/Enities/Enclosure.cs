using Domain.Enities;
using Domain.ValueObjects;
using FluentAssertions;
using Xunit;

namespace ZooTests.Domain.Enities;

public class EnclosureTests
{
    [Fact]
    public void AddAnimal_WhenEnclosureNotFull_AddsAnimal()
    {
        // Arrange
        var enclosure = new Enclosure(
            enclosureId: Guid.NewGuid(),
            enclosureType: EnclosureType.ForPredators,
            length: 10,
            width: 5,
            height: 3,
            numberOfAnimal: 0,
            maxNumberOfAnimal: 5,
            animals: new List<Animal>(),
            frequencyLevel: 100
        );

        var animal = new Animal(
            id: Guid.NewGuid(),
            breed: "Лев",
            name: "Симба",
            birthDate: DateTime.Now,
            gender: AnimalGender.Male,
            favoriteFood: "Мясо",
            healthStatus: AnimalHealthStatus.Healthy,
            hunger: 5,
            happiness: 5
        );

        // Act
        enclosure.AddAnimal(animal);

        // Assert
        enclosure.NumberOfAnimal.Should().Be(1);
        enclosure.GetAnimals().Should().Contain(animal);
    }
    
    [Fact]
    public void RemoveAnimal_ValidAnimal_DecreasesCount()
    {
        // Arrange
        var animal = new Animal(
            id: Guid.NewGuid(),
            breed: "Лев",
            name: "Симба",
            birthDate: DateTime.Now,
            gender: AnimalGender.Male,
            favoriteFood: "Мясо",
            healthStatus: AnimalHealthStatus.Healthy,
            hunger: 5,
            happiness: 5
        );

        var enclosure = new Enclosure(
            enclosureId: Guid.NewGuid(),
            enclosureType: EnclosureType.ForPredators,
            length: 10,
            width: 5,
            height: 3,
            numberOfAnimal: 1,
            maxNumberOfAnimal: 5,
            animals: new List<Animal> { animal },
            frequencyLevel: 100
        );

        // Act
        enclosure.RemoveAnimal(animal);

        // Assert
        enclosure.NumberOfAnimal.Should().Be(0);
        enclosure.GetAnimals().Should().NotContain(animal);
    }
    [Fact]
    public void Pollute_DecreasesFrequencyLevelByOne()
    {
        // Arrange
        var enclosure = new Enclosure(
            enclosureId: Guid.NewGuid(),
            enclosureType: EnclosureType.ForPredators,
            length: 10,
            width: 5,
            height: 3,
            numberOfAnimal: 0,
            maxNumberOfAnimal: 5,
            animals: new List<Animal>(),
            frequencyLevel: 100
        );

        // Act
        enclosure.Pollute();

        // Assert
        enclosure.FrequencyLevel.Should().Be(99);
    }
    [Fact]
    public void Clean_IncreasesFrequencyLevelByOneAndReturnsMessage()
    {
        // Arrange
        var enclosureId = Guid.NewGuid();
        var enclosure = new Enclosure(
            enclosureId: enclosureId,
            enclosureType: EnclosureType.ForPredators,
            length: 10,
            width: 5,
            height: 3,
            numberOfAnimal: 0,
            maxNumberOfAnimal: 5,
            animals: new List<Animal>(),
            frequencyLevel: 100
        );

        // Act
        var result = enclosure.Clean();

        // Assert
        enclosure.FrequencyLevel.Should().Be(101);
        result.Should().Be($"Enclosure with id:{enclosureId} was cleaned.");
    }
}