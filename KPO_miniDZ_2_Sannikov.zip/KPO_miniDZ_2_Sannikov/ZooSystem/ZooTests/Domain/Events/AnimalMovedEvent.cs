using Domain.Events;
using Xunit;

namespace ZooTests.Domain.Events
{
    public class AnimalMovedEventTests
    {
        [Fact]
        public void Constructor_ShouldInitializeAllProperties()
        {
            // Arrange
            var animalId = Guid.NewGuid();
            var prevId = Guid.NewGuid();
            var newId = Guid.NewGuid();

            // Act
            var @event = new AnimalMovedEvent(animalId, prevId, newId);

            // Assert
            Assert.Equal(animalId, @event.AnimalId);
            Assert.Equal(prevId, @event.PreviousEnclosureId);
            Assert.Equal(newId, @event.NewEnclosureId);
            Assert.IsAssignableFrom<IDomainEvent>(@event);
        }

        [Fact]
        public void OccurredOn_ShouldBeSetToUtcNow()
        {
            // Arrange
            var before = DateTime.UtcNow;

            // Act
            var @event = new AnimalMovedEvent(Guid.NewGuid(), Guid.NewGuid(), Guid.NewGuid());
            var after = DateTime.UtcNow;

            // Assert
            Assert.InRange(@event.OccurredOn, before, after);
        }
    }
}