using Domain.Enities;
using Domain.Events;
using Domain.ValueObjects;
using Xunit;

namespace ZooTests.Domain.Events
{
    public class FeedingTimeEventTests
    {
        [Fact]
        public void Constructor_ShouldBindFeedingSchedule()
        {
            // Arrange
            var schedule = new FeedingSchedule(
                Guid.NewGuid(),
                new Animal(
                    Guid.NewGuid(), "Lion", "Simba",
                    DateTime.Now, AnimalGender.Male, 
                    "Meat", AnimalHealthStatus.Healthy, 5),
                DateTime.Now.AddHours(2),
                "Meat"
            );

            // Act
            var @event = new FeedingTimeEvent(schedule);

            // Assert
            Assert.Same(schedule, @event.FeedingSchedule);
            Assert.IsAssignableFrom<IDomainEvent>(@event);
        }

        [Fact]
        public void OccurredOn_ShouldBeSetToUtcNow()
        {
            // Arrange
            var before = DateTime.UtcNow;

            // Act
            var @event = new FeedingTimeEvent(new FeedingSchedule(
                Guid.NewGuid(),
                new Animal(
                    Guid.NewGuid(), "Tiger", "Tony",
                    DateTime.Now, AnimalGender.Female,
                    "Fish", AnimalHealthStatus.Healthy, 3),
                DateTime.Now.AddHours(3),
                "Fish"
            ));

            // Assert
            Assert.InRange(@event.OccurredOn, before, DateTime.UtcNow);
        }
    }
}