using System.ComponentModel.DataAnnotations;

namespace Application.Dtos;

public class FeedingScheduleCreateDto
{
    [Required] public Guid AnimalId { get; set; }
    public DateTime FeedingTime { get; set; }
    public string Food { get; set; } = null!;
    public bool Done { get; set; }
}