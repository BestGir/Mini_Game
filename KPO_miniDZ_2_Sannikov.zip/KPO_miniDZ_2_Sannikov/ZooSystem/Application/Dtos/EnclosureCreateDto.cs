using System.ComponentModel.DataAnnotations;
using Domain.ValueObjects;

namespace Application.Dtos;

public class EnclosureCreateDto
{
    [Required]
    public EnclosureType Type { get; set; }

    [Range(1, uint.MaxValue, ErrorMessage = "Длина должна быть положительной")]
    public uint Length { get; set; }

    [Range(1, uint.MaxValue, ErrorMessage = "Ширина должна быть положительной")]
    public uint Width { get; set; }

    [Range(1, uint.MaxValue, ErrorMessage = "Высота должна быть положительной")]
    public uint Height { get; set; }

    [Range(1, uint.MaxValue, ErrorMessage = "Вместимость должна быть положительной")]
    public uint MaxNumberOfAnimal { get; set; }
}