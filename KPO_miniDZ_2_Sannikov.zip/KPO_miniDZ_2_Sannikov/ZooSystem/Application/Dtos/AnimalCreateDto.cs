using System.ComponentModel.DataAnnotations;
using Domain.ValueObjects;

namespace Application.Dtos;
public class AnimalCreateDto
{
    [Required] public string Breed { get; set; } = default!;
    
    [Required] public string Name { get; set; } = default!;
    [Required] public DateTime BirthDate { get; set; }
    [Required] public AnimalGender Gender { get; set; }
    [Required] public string FavoriteFood { get; set; } = default!;
    [Required] public AnimalHealthStatus HealthStatus { get; set; }
    [Range(0, 10)] public int Hunger { get; set; }
    [Range(0, 10)] public int Happiness { get; set; }
    [Required] public Guid EnclosureId { get; set; }
}