namespace Application.Dtos;

public class AnimalTransferDto
{
    public Guid AnimalId { get; init; }
    public Guid NewEnclosureId { get; init; }
}