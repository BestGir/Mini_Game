using Domain.Events;

namespace Application.EventHandlers;

public interface IDomainEventHandler<in T> where T: IDomainEvent
{
    public void Handle(T domainEvent);
}