using Domain.Events;

namespace Application.EventHandlers;

public interface IDomainEventDispatcher
{
    public void Register<TEvent>(TEvent domainEvent) where TEvent : IDomainEvent;
    public void Dispatch<TEvent>(TEvent domainEvent) where TEvent : IDomainEvent;
}