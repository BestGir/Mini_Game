using Application.EventHandlers;
using Domain.Enities;
using Domain.Events;
using Domain.RepositoryInterfaces;

namespace Application.Services;

public class FeedingOrganizationService(
    IFeedingScheduleRepository feedingScheduleRepository,
    IDomainEventDispatcher eventDispatcher)
{
    public void AddScheduleFeeding(Animal animal, DateTime time, string foodType)
    {
        Guid newFeedingId = Guid.NewGuid();
        var schedule = new FeedingSchedule(newFeedingId, animal, time, foodType);
        feedingScheduleRepository.Add(schedule);
        eventDispatcher.Dispatch(new FeedingTimeEvent(schedule));
    }

    public IEnumerable<FeedingSchedule> GetFeedingSchedules() 
        => feedingScheduleRepository.GetAllFeedingSchedules();
}