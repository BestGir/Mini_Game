using Application.EventHandlers;
using Domain.RepositoryInterfaces;

namespace Application.Services;

public class AnimalTransferService
{
    private readonly IAnimalRepository _animalRepository;
    private readonly IEnclosureRepository _enclosureRepository;
    private readonly IDomainEventDispatcher _eventDispatcher;

    public AnimalTransferService(
        IAnimalRepository animalRepository,
        IEnclosureRepository enclosureRepository,
        IDomainEventDispatcher eventDispatcher)
    {
        _animalRepository = animalRepository;
        _enclosureRepository = enclosureRepository;
        _eventDispatcher = eventDispatcher;
    }

    public void TransferAnimal(Guid animalId, Guid newEnclosureId)
    {
        var animal = _animalRepository.GetAnimalById(animalId);
        var newEnclosure = _enclosureRepository.GetEnclosureById(newEnclosureId);
        var previousEnclosure = _enclosureRepository.GetEnclosureById(animal.EnclosureId);

        if (newEnclosure.GetType() != previousEnclosure.GetType())
            throw new InvalidOperationException("Тип вольера не совместим с животным!");

        previousEnclosure.RemoveAnimal(animal);
        animal.SetNewEnclosureId(newEnclosureId);
        newEnclosure.AddAnimal(animal);

        foreach (var domainEvent in animal.DomainEvents)
        {
            _eventDispatcher.Dispatch(domainEvent);
        }

        animal.ClearDomainEvents();
    }
}
