using Domain.RepositoryInterfaces;

namespace Application.Services;

public class ZooStatisticsService(
    IAnimalRepository animalRepository,
    IEnclosureRepository enclosureRepository)
{
    public int GetAnimalAmount()
    {
        return animalRepository.GetAnimalsCount();
    }

    public int GetAmountOfEnclosuresWithFreeSpace()
    {
        return enclosureRepository.GetFreeEnclosureCount();
    }
}