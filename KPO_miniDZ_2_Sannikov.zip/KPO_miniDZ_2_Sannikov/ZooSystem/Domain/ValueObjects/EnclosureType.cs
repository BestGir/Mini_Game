using System.Runtime.Serialization;

namespace Domain.ValueObjects;

public enum EnclosureType
{
    [EnumMember(Value = "ForPredators")]
    ForPredators,
    [EnumMember(Value = "ForHerbivores")]
    ForHerbivores,
    [EnumMember(Value = "Aquarium")]
    Aquarium,
    [EnumMember(Value = "ForBirds")]
    ForBirds
}