using System.Runtime.Serialization;

namespace Domain.ValueObjects;

public enum AnimalHealthStatus
{
    [EnumMember(Value = "Healthy")]
    Healthy,
    [EnumMember(Value = "Sick")]
    Sick
}