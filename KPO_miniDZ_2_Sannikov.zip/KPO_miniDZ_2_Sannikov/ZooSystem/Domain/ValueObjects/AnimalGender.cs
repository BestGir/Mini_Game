using System.Runtime.Serialization;

namespace Domain.ValueObjects;

public enum AnimalGender
{
    
    [EnumMember(Value = "Female")]
    Female,
    [EnumMember(Value = "Male")]
    Male,
    [EnumMember(Value = "Hermaphrodites")]
    Hermaphrodites
}