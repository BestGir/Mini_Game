namespace Domain.Enities;

public class FeedingSchedule(
    Guid feedingScheduleId, 
    Animal animal, 
    DateTime feedingTime, 
    string food, 
    bool done = false)
{
    public Guid FeedingScheduleId { get; set; } = feedingScheduleId;
    public Animal Animal { get; private set; } = animal;
    public DateTime FeedingTime { get; private set; } = feedingTime;
    public string Food { get; private set; } = food;
    public bool Done { get; private set; } = done;
    
    public void ChangeFeedingTime(DateTime feedingTime)
    {
        FeedingTime = feedingTime;
    }

    public void ChangeFood(string food)
    {
        Food = food;
    }
    
    public void MarkDone()
    {
        Done = true;
    }

    public void UnMarkDone()
    {
        Done = false;
    }
}