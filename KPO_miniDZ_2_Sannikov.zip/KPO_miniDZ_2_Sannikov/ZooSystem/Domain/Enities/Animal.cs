using Domain.Events;
using Domain.ValueObjects;

namespace Domain.Enities;


public class Animal(
    Guid id,
    string breed,
    string name,
    DateTime birthDate,
    AnimalGender gender,
    string favoriteFood,
    AnimalHealthStatus healthStatus,
    int hunger,
    int happiness = 0)
{
    public Guid AnimalId {get; set;} = id;
    public string Breed {get; private set;} = breed;
    public string Name {get; private set;} = name;
    public DateTime BirthDate {get; private set;} = birthDate;
    public AnimalGender Gender {get; private set;} = gender;
    public string FavoriteFood {get; set;} = favoriteFood;
    public AnimalHealthStatus HealthStatus {get; private set;} = healthStatus;
    public int Hunger {get; private set;} =  hunger;
    public int Happiness {get; private set;} =  happiness;
    public Guid EnclosureId {get; set;}

    public List<IDomainEvent> DomainEvents {get; set;} = [];

    public void Feed(string food)
    {
        Hunger--;
        if (food.ToLower().Equals(FavoriteFood))
        {
            Happiness++;
        }
        else
        {
            Happiness--;
        }
    }

    public void Treat()
    {
        HealthStatus = Happiness > 5 ? AnimalHealthStatus.Healthy : AnimalHealthStatus.Sick;
    }

    public void SetNewEnclosureId(Guid enclosureId)
    {
        DomainEvents.Add(new AnimalMovedEvent(AnimalId, EnclosureId, enclosureId));
        EnclosureId = enclosureId;
    }

    public void ClearDomainEvents()
    {
        DomainEvents.Clear();
    }
}
    
    