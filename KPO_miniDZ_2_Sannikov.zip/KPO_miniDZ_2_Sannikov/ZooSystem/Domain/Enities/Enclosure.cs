using Domain.ValueObjects;

namespace Domain.Enities;

public class Enclosure(
    Guid enclosureId,
    EnclosureType enclosureType,
    uint length,
    uint width,
    uint height,
    int numberOfAnimal,
    uint maxNumberOfAnimal,
    List<Animal> animals,
    uint frequencyLevel)
{
    public Guid EnclosureId { get; set; } = enclosureId;
    public EnclosureType Type { get; set; }
    public uint Length {get; private set;} = length;
    public uint Width {get; private set;} = width;
    public uint Height {get; private set;} = height;
    public int NumberOfAnimal {get; set;} = numberOfAnimal;
    public uint MaxNumberOfAnimal {get; set;} = maxNumberOfAnimal;
    private readonly List<Animal> _animals = animals;
    public uint FrequencyLevel {get; set;} = frequencyLevel;

    public void AddAnimal(Animal animal)
    {
        if (_animals.Contains(animal))
        {
            return;
        }

        if (_animals.Count >= MaxNumberOfAnimal)
        {
            throw new Exception("Too many animals in enclosure!");
        }
        _animals.Add(animal);
        NumberOfAnimal++;
    }

    public void RemoveAnimal(Animal animal)
    {
        _animals.Remove(animal);
        NumberOfAnimal--;
    }

    public List<Animal> GetAnimals()
    {
        return _animals;
    }

    public void Pollute()
    {
        FrequencyLevel--;
    }

    public string Clean()
    { 
        FrequencyLevel++;
        return $"Enclosure with id:{EnclosureId} was cleaned.";
    }
}