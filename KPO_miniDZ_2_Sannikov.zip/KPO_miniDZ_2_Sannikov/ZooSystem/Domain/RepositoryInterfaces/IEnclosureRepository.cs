using Domain.Enities;

namespace Domain.RepositoryInterfaces;

public interface IEnclosureRepository
{
    public Enclosure GetEnclosureById(Guid id);
    public IEnumerable<Enclosure> GetEnclosures();
    public void Add(Enclosure enclosure);
    public void Remove(Enclosure enclosure);
    public int GetEnclosureCount();
    public int GetFreeEnclosureCount();
}