using Domain.Enities;

namespace Domain.RepositoryInterfaces;

public interface IAnimalRepository
{
    public IEnumerable<Animal> GetAll();
    public Animal GetAnimalById(Guid id);
    public void Add(Animal animal);
    public void Remove(Guid id);
    public int GetAnimalsCount();
}