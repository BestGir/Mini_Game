using Domain.Enities;

namespace Domain.RepositoryInterfaces;

public interface IFeedingScheduleRepository
{
    public IEnumerable<FeedingSchedule> GetAllFeedingSchedules();
    public FeedingSchedule GetFeedingScheduleById(Guid id);
    public void Add(FeedingSchedule feedingSchedule);
    public void Remove(Guid id);
    void Update(FeedingSchedule schedule);
}