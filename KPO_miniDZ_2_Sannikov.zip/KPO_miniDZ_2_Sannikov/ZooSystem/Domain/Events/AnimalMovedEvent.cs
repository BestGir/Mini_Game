namespace Domain.Events;

public class AnimalMovedEvent(Guid animalId, Guid previousEnclosureId, Guid newEnclosureId)
    : IDomainEvent
{
    public Guid AnimalId { get; init; } = animalId;
    public Guid PreviousEnclosureId { get; init; } = previousEnclosureId;
    public Guid NewEnclosureId { get; init; } = newEnclosureId;
    public DateTime OccurredOn { get; init; } = DateTime.UtcNow;
}