using Domain.Enities;

namespace Domain.Events;

public class FeedingTimeEvent(FeedingSchedule feedingSchedule) : IDomainEvent
{
    public DateTime OccurredOn { get; init; } = DateTime.UtcNow;
    public FeedingSchedule FeedingSchedule { get; init; } = feedingSchedule;
}