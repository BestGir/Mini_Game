using Domain.Enities;
using Domain.RepositoryInterfaces;

namespace Infrastructure.Repositories;

public class InMemoryAnimalRepository : IAnimalRepository
{
    private readonly List<Animal> _animals = new();
    
    public int GetAnimalsAmount() => _animals.Count;
    
    public Animal GetById(Guid id) 
        => _animals.FirstOrDefault(a => a.AnimalId == id) 
           ?? throw new KeyNotFoundException($"Animal {id} not found.");

    public IEnumerable<Animal> GetAll() => new List<Animal>(_animals);

    public Animal GetAnimalById(Guid id)
    {
        var animal = _animals.FirstOrDefault(a => a.AnimalId == id);
        return animal ?? throw new KeyNotFoundException($"Animal {id} not found.");
    }

    public void Add(Animal animal) => _animals.Add(animal);
    public void Remove(Guid id)
    {
        var animal = GetAnimalById(id); 
        _animals.Remove(animal);
    }

    public int GetAnimalsCount() => _animals.Count;

    public void Update(Animal animal)
    {
        var index = _animals.FindIndex(a => a.AnimalId == animal.AnimalId);
        if (index != -1) _animals[index] = animal;
    }
}