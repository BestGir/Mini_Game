using Domain.Enities;
using Domain.RepositoryInterfaces;

namespace Infrastructure.Repositories;

public class InMemoryEnclosureRepository : IEnclosureRepository
{
    private static readonly List<Enclosure> Enclosures = new();

    public Enclosure GetEnclosureById(Guid id)
    {
        var enclosure = Enclosures.FirstOrDefault(e => e.EnclosureId == id);
        return enclosure ?? throw new KeyNotFoundException($"Enclosure {id} not found.");
    }

    public void Add(Enclosure enclosure) => Enclosures.Add(enclosure);

    public void Remove(Enclosure enclosure) => Enclosures.Remove(enclosure);

    public int GetEnclosureCount() => Enclosures.Count;

    public IEnumerable<Enclosure> GetEnclosures() => new List<Enclosure>(Enclosures);
    public int GetFreeEnclosureCount() 
        => Enclosures.Count(e => e.NumberOfAnimal < e.MaxNumberOfAnimal);
}