using Domain.Enities;
using Domain.RepositoryInterfaces;

namespace Infrastructure.Repositories;

public class InMemoryFeedingScheduleRepository : IFeedingScheduleRepository
{
    private readonly List<FeedingSchedule> _schedules = new();

    public FeedingSchedule GetFeedingScheduleById(Guid id)
    {
        throw new NotImplementedException();
    }
    
    public void Update(FeedingSchedule schedule) 
    {
        var index = _schedules.FindIndex(s => s.FeedingScheduleId == schedule.FeedingScheduleId);
        if (index != -1)
        {
            _schedules[index] = schedule;
        }
    }
    
    void IFeedingScheduleRepository.Add(FeedingSchedule feedingSchedule)
    {
        Add(feedingSchedule);
    }

    public void Add(FeedingSchedule schedule)
    {
        _schedules.Add(schedule);
    }

    public FeedingSchedule GetById(Guid id)
    {
        var schedule = _schedules.FirstOrDefault(s => s.FeedingScheduleId == id);
        return schedule ?? throw new KeyNotFoundException($"Расписание с ID {id} не найдено.");
    }

    public IEnumerable<FeedingSchedule> GetAllFeedingSchedules()
    {
        return _schedules.ToList();
    }

    public void Remove(Guid id)
    {
        var schedule = GetById(id); 
        _schedules.Remove(schedule);
    }

    public IEnumerable<FeedingSchedule> GetByAnimalId(Guid animalId)
    {
        return _schedules.Where(s => s.Animal.AnimalId == animalId).ToList();
    }
}