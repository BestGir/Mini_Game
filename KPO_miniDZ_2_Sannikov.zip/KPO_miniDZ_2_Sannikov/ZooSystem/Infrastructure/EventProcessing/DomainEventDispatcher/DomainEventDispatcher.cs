using Application.EventHandlers;
using Domain.Events;
using Microsoft.Extensions.DependencyInjection;

namespace Infrastructure.EventProcessing.DomainEventDispatcher;

public class DomainEventDispatcher(IServiceProvider serviceProvider) : IDomainEventDispatcher
{
    public void Register<TEvent>(TEvent @event) where TEvent : IDomainEvent
    {
        throw new NotImplementedException();
    }

    public void Dispatch<TEvent>(TEvent @event) where TEvent : IDomainEvent
    {
        var handlers = serviceProvider.GetServices<IDomainEventHandler<TEvent>>();
        foreach (var handler in handlers)
        {
            handler.Handle(@event);
        }
    }
}