using Application.EventHandlers;
using Domain.Events;
using Domain.RepositoryInterfaces;

namespace Infrastructure.EventProcessing.EventHandlers;

public class AnimalMovedEventHandler(
    IAnimalRepository animalRepository,
    IEnclosureRepository enclosureRepository)
    : IDomainEventHandler<AnimalMovedEvent>
{
    private readonly IAnimalRepository _animalRepository = animalRepository 
                                                           ?? throw new ArgumentNullException(nameof(animalRepository));
    private readonly IEnclosureRepository _enclosureRepository = enclosureRepository 
                                                                 ?? throw new ArgumentNullException(nameof(enclosureRepository));

    public void Handle(AnimalMovedEvent domainEvent)
    {
        ArgumentNullException.ThrowIfNull(domainEvent);

        if (domainEvent.AnimalId == Guid.Empty)
            throw new ArgumentException("Invalid AnimalId.");
        if (domainEvent.NewEnclosureId == Guid.Empty)
            throw new ArgumentException("Invalid NewEnclosureId.");

        var animal = _animalRepository.GetAnimalById(domainEvent.AnimalId);
        var prevEnclosure = _enclosureRepository.GetEnclosureById(domainEvent.PreviousEnclosureId);
        var newEnclosure = _enclosureRepository.GetEnclosureById(domainEvent.NewEnclosureId);

        if (prevEnclosure.Type != newEnclosure.Type)
            throw new InvalidOperationException("Enclosure type mismatch.");

        if (newEnclosure.NumberOfAnimal >= newEnclosure.MaxNumberOfAnimal)
            throw new InvalidOperationException("New enclosure is full.");

        prevEnclosure.RemoveAnimal(animal);
        newEnclosure.AddAnimal(animal);

    }
}