using Application.EventHandlers;
using Application.Services;
using Domain.Events;

namespace Infrastructure.EventProcessing.EventHandlers;

public class FeedingTimeEventHandler(FeedingOrganizationService feedingOrganizationService)
    : IDomainEventHandler<FeedingTimeEvent>
{
    private readonly FeedingOrganizationService _feedingScheduleService = feedingOrganizationService;

    public void Handle(FeedingTimeEvent domainEvent)
    {
        ArgumentNullException.ThrowIfNull(domainEvent);

        if (domainEvent.FeedingSchedule.Animal.AnimalId == Guid.Empty)
        {
            throw new ArgumentException("Invalid AnimalId.");
        }

        domainEvent.FeedingSchedule.MarkDone();
    }
}