using Application.Dtos;
using Domain.Enities;
using Domain.RepositoryInterfaces;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers;

[ApiController]
[Route("api/enclosures")]
public class EnclosureController(IEnclosureRepository enclosureRepository) : ControllerBase
{
    [HttpPost]
    public IActionResult AddEnclosure([FromBody] EnclosureCreateDto dto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        try
        {
            var enclosure = new Enclosure(
                enclosureId: Guid.NewGuid(),
                enclosureType: dto.Type,
                length: dto.Length,
                width: dto.Width,
                height: dto.Height,
                numberOfAnimal: 0, 
                maxNumberOfAnimal: dto.MaxNumberOfAnimal,
                animals: new List<Animal>(),
                frequencyLevel: 100 
            );

            enclosureRepository.Add(enclosure);
            return CreatedAtAction(nameof(GetEnclosure), new { id = enclosure.EnclosureId }, enclosure);
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteEnclosure(Guid id)
    {
        try
        {
            var enclosure = enclosureRepository.GetEnclosureById(id);
            enclosureRepository.Remove(enclosure);
            return NoContent();
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
    }

    [HttpGet("{id}")]
    public IActionResult GetEnclosure(Guid id)
    {
        try
        {
            var enclosure = enclosureRepository.GetEnclosureById(id);
            return Ok(enclosure);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
    }

    [HttpGet]
    public IActionResult GetAllEnclosures()
    {
        var enclosures = enclosureRepository.GetEnclosures();
        return Ok(enclosures);
    }
}