using Application.Dtos;
using Application.Services;
using Domain.RepositoryInterfaces;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers;

[ApiController]
[Route("api/feeding-schedules")]
public class FeedingScheduleController(
    FeedingOrganizationService feedingService,
    IAnimalRepository animalRepository,
    IFeedingScheduleRepository feedingScheduleRepository)
    : ControllerBase
{
    [HttpGet]
    [HttpGet]
    public IActionResult GetAllFeedingSchedules()
    {
        var schedules = feedingScheduleRepository.GetAllFeedingSchedules();
        return Ok(schedules);
    }

    [HttpPost]
    public IActionResult AddFeedingSchedule([FromBody] FeedingScheduleCreateDto dto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        try
        {
            var animal = animalRepository.GetAnimalById(dto.AnimalId);
            
            feedingService.AddScheduleFeeding(
                animal: animal,
                time: dto.FeedingTime,
                foodType: dto.Food
            );

            return CreatedAtAction(nameof(GetAllFeedingSchedules), null);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound($"Animal {dto.AnimalId} not found.");
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    [HttpPut("{id}/mark-done")]
    public IActionResult MarkFeedingAsDone(Guid id)
    {
        try
        {
            var schedule = feedingScheduleRepository.GetFeedingScheduleById(id);
            schedule.MarkDone();
            feedingScheduleRepository.Update(schedule);
            return Ok();
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound($"Feeding schedule {id} not found.");
        }
    }
}