using Application.Dtos;
using Application.Services;
using Domain.Enities;
using Domain.RepositoryInterfaces;
using Microsoft.AspNetCore.Mvc;

namespace Presentation.Controllers;

[ApiController]
[Route("api/animals")]
public class AnimalController(
    IAnimalRepository animalRepository,
    IEnclosureRepository enclosureRepository,
    AnimalTransferService transferService)
    : ControllerBase
{
    private readonly AnimalTransferService _transferService = transferService;

    [HttpPost]
    public IActionResult AddAnimal([FromBody] AnimalCreateDto dto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest(ModelState);
        }

        try
        {
            var enclosure = enclosureRepository.GetEnclosureById(dto.EnclosureId);

            var animal = new Animal(
                id: Guid.NewGuid(),
                breed: dto.Breed,
                name: dto.Name,
                birthDate: dto.BirthDate,
                gender: dto.Gender,
                favoriteFood: dto.FavoriteFood,
                healthStatus: dto.HealthStatus,
                hunger: dto.Hunger,
                happiness: dto.Happiness
            )
            {
                EnclosureId = dto.EnclosureId
            };

            animalRepository.Add(animal);
            enclosure.AddAnimal(animal);

            return CreatedAtAction(nameof(GetAnimal), new { id = animal.AnimalId }, animal);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound($"Enclosure {dto.EnclosureId} not found.");
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    [HttpDelete("{id}")]
    public IActionResult DeleteAnimal(Guid id)
    {
        try
        {
            animalRepository.Remove(id);
            return NoContent();
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
    }

    [HttpGet("{id}")]
    public IActionResult GetAnimal(Guid id)
    {
        try
        {
            var animal = animalRepository.GetAnimalById(id);
            return Ok(animal);
        }
        catch (KeyNotFoundException ex)
        {
            return NotFound(ex.Message);
        }
    }

    [HttpGet]
    public IActionResult GetAllAnimals()
    {
        var animals = animalRepository.GetAll();
        return Ok(animals);
    }
}